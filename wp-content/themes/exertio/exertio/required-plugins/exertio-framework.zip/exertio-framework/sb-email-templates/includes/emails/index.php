<?php

/*
 * Silence is Gold
 */