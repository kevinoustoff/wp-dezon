<?php
/*
 * Silence is gold
 */